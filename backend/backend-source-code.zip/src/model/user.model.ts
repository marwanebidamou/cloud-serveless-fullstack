export interface User {
    name: string;
    email: string;
    phone: string;
    address: string;
    occupation: string;
    password: string;
    profileImageUrl: string;
}